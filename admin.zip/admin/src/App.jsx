import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import ProductList from './components/ProductList';
import ProductForm from './components/ProductForm';
import OrderList from './components/OrderList';
import ProtectedRoute from './components/ProtectedRoute';
import AdminNavbar from './components/AdminNavbar';
import BannerManagement from './components/BannerManagement';
import BannerForm from './components/BannerForm';
import ApkUpload from './components/ApkUpload';
import Settings from './components/Setting';
import TransactionHistory from './components/TransactionHistory';
import AdminPaymentNotification from './components/AdminPaymentNotification';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Public Login Route */}
          <Route path="/admin/login" element={<AdminLogin />} />

          {/* Protected Admin Routes */}
          <Route path="/admin/*" element={
            <ProtectedRoute>
              <div className="min-h-screen bg-gray-50">
                <AdminNavbar />

                {/* ✅ Global real-time notification popup — always mounted when logged in */}
                <AdminPaymentNotification />

                <main>
                  <Routes>
                    <Route path="dashboard" element={<AdminDashboard />} />
                    <Route path="products" element={<ProductList />} />
                    <Route path="apk" element={<ApkUpload />} />
                    <Route path="products/create" element={<ProductForm />} />
                    <Route path="products/edit/:id" element={<ProductForm />} />
                    <Route path="orders" element={<OrderList />} />
                    <Route path="orders/:id" element={<OrderList />} />
                    <Route path="banners" element={<BannerManagement />} />
                    <Route path="banners/create" element={<BannerForm />} />
                    <Route path="banners/edit/:id" element={<BannerForm />} />
                    <Route path="settings" element={<Settings />} />

                    {/* ✅ New transaction history route */}
                    <Route path="transactions" element={
                      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
                        <TransactionHistory />
                      </div>
                    } />

                    <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
                  </Routes>
                </main>
              </div>
            </ProtectedRoute>
          } />

          <Route path="/" element={<Navigate to="/admin/login" replace />} />
          <Route path="*" element={<Navigate to="/admin/login" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;