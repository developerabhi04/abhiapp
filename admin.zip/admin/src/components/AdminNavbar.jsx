import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import authService from '../services/authService';

const AdminNavbar = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    const currentAdmin = authService.getCurrentAdmin();

    const handleLogout = async () => {
        if (window.confirm('Are you sure you want to logout?')) {
            await authService.logout();
            navigate('/admin/login');
        }
    };

    const isActiveLink = (path) => location.pathname.includes(path);

    // ✅ Each link has either a svgPath OR an emoji icon
    const navLinks = [
        {
            path: '/admin/dashboard',
            label: 'Dashboard',
            svgPath: 'M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z'
        },
        {
            path: '/admin/products',
            label: 'Products',
            svgPath: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4'
        },
        {
            path: '/admin/orders',
            label: 'Orders',
            svgPath: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2'
        },
        {
            path: '/admin/transactions',
            label: 'Transactions',
            svgPath: 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z'
        },
        {
            path: '/admin/banners',
            label: 'Banners',
            svgPath: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z'
        },
        {
            path: '/admin/settings',
            label: 'UPI Settings',
            emoji: '⚙️'
        }
    ];

    const NavIcon = ({ link, size = 'w-4 h-4' }) => {
        if (link.emoji) {
            return <span className="text-base leading-none">{link.emoji}</span>;
        }
        return (
            <svg className={size} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={link.svgPath} />
            </svg>
        );
    };

    return (
        <nav className="bg-white shadow-lg border-b border-gray-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-16">

                    {/* Logo */}
                    <div className="flex items-center">
                        <Link to="/admin/dashboard" className="flex items-center space-x-2">
                            <div className="bg-indigo-600 p-2 rounded-lg">
                                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                </svg>
                            </div>
                            <span className="text-xl font-bold text-gray-900">DMart Admin</span>
                        </Link>
                    </div>

                    {/* Desktop Navigation */}
                    <div className="hidden md:flex items-center space-x-1">
                        {navLinks.map((link) => (
                            <Link
                                key={link.path}
                                to={link.path}
                                className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${isActiveLink(link.path)
                                    ? 'bg-indigo-100 text-indigo-700'
                                    : 'text-gray-600 hover:text-indigo-600 hover:bg-gray-100'
                                    }`}
                            >
                                <NavIcon link={link} size="w-4 h-4" />
                                <span>{link.label}</span>

                                {/* ✅ Red badge on Transactions if on that page — you can later wire live count here */}
                                {link.path === '/admin/transactions' && (
                                    <span className="ml-1 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full leading-none">

                                    </span>
                                )}
                            </Link>
                        ))}
                    </div>

                    {/* User Menu + Logout */}
                    <div className="flex items-center space-x-4">
                        <div className="hidden md:flex items-center space-x-3">
                            <div className="text-sm">
                                <p className="font-medium text-gray-900">Welcome back,</p>
                                <p className="text-gray-600">{currentAdmin?.name || currentAdmin?.username}</p>
                            </div>
                            <div className="h-8 w-8 bg-indigo-600 rounded-full flex items-center justify-center">
                                <span className="text-white text-sm font-medium">
                                    {(currentAdmin?.name || currentAdmin?.username)?.charAt(0).toUpperCase()}
                                </span>
                            </div>
                        </div>

                        <button
                            onClick={handleLogout}
                            className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors duration-200 flex items-center space-x-2"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                            </svg>
                            <span className="hidden sm:inline">Logout</span>
                        </button>

                        {/* Mobile hamburger */}
                        <div className="md:hidden">
                            <button
                                onClick={() => setIsMenuOpen(!isMenuOpen)}
                                className="text-gray-600 hover:text-gray-900 focus:outline-none"
                            >
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    {isMenuOpen ? (
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                                    ) : (
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                                    )}
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="md:hidden bg-white border-t border-gray-200">
                    <div className="px-2 pt-2 pb-3 space-y-1">
                        {navLinks.map((link) => (
                            <Link
                                key={link.path}
                                to={link.path}
                                onClick={() => setIsMenuOpen(false)}
                                className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-base font-medium ${isActiveLink(link.path)
                                    ? 'bg-indigo-100 text-indigo-700'
                                    : 'text-gray-600 hover:text-indigo-600 hover:bg-gray-100'
                                    }`}
                            >
                                <NavIcon link={link} size="w-5 h-5" />
                                <span>{link.label}</span>
                            </Link>
                        ))}

                        {/* Mobile user info */}
                        <div className="px-3 py-3 border-t border-gray-200 mt-2">
                            <p className="text-sm font-medium text-gray-900">{currentAdmin?.name || currentAdmin?.username}</p>
                            <p className="text-xs text-gray-500">Admin</p>
                        </div>
                    </div>
                </div>
            )}
        </nav>
    );
};

export default AdminNavbar;