import { useEffect, useState, useRef } from 'react';
import { io } from 'socket.io-client';
import { motion, AnimatePresence } from 'framer-motion';
import paymentService from '../services/paymentService';

const SOCKET_URL =
    import.meta.env.VITE_SOCKET_URL ||
    import.meta.env.VITE_API_URL?.replace('/api', '') ||
    'http://localhost:5000';

// ── OS Notification permission ─────────────────────────────────
const requestNotificationPermission = async () => {
    if (!('Notification' in window)) return 'unsupported';
    if (Notification.permission === 'granted') return 'granted';
    if (Notification.permission === 'denied') return 'denied';
    return await Notification.requestPermission();
};

const showOSNotification = (data) => {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const productNames = data.products?.map(p => p.name).join(', ') || 'Products';
    const notif = new Notification('💰 New Payment Alert — DMart Admin', {
        body: `${data.userName} • ₹${Number(data.totalAmount).toLocaleString('en-IN')}\n${productNames}`,
        icon: '/favicon.ico', badge: '/favicon.ico', tag: data.tid,
        requireInteraction: true, vibrate: [200, 100, 200, 100, 200],
    });
    notif.onclick = () => { window.focus(); window.location.href = '/admin/transactions'; notif.close(); };
    setTimeout(() => notif.close(), 30000);
};

// ── Web Audio API — Cash register sound ───────────────────────
let _audioCtx = null;
const getAudioCtx = () => {
    if (!_audioCtx || _audioCtx.state === 'closed') {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return null;
        _audioCtx = new Ctx();
    }
    return _audioCtx;
};
const unlockAudioCtx = () => {
    const ctx = getAudioCtx();
    if (ctx?.state === 'suspended') ctx.resume().catch(() => { });
};

const playBeepSound = () => {
    try {
        const ctx = getAudioCtx();
        if (!ctx) return;
        const play = () => {
            const now = ctx.currentTime;
            // Mechanical click
            const clickBuffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.04), ctx.sampleRate);
            const clickData = clickBuffer.getChannelData(0);
            for (let i = 0; i < clickData.length; i++)
                clickData[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / clickData.length, 3);
            const clickSource = ctx.createBufferSource();
            clickSource.buffer = clickBuffer;
            const clickGain = ctx.createGain();
            clickGain.gain.setValueAtTime(0.6, now);
            clickSource.connect(clickGain); clickGain.connect(ctx.destination);
            clickSource.start(now);
            // Coin cascade
            [
                { freq: 1200, start: 0.02, dur: 0.12, vol: 0.5 },
                { freq: 1500, start: 0.09, dur: 0.14, vol: 0.6 },
                { freq: 1900, start: 0.18, dur: 0.18, vol: 0.7 },
                { freq: 2400, start: 0.30, dur: 0.22, vol: 0.75 },
            ].forEach(({ freq, start, dur, vol }) => {
                const osc = ctx.createOscillator(); const gain = ctx.createGain();
                osc.connect(gain); gain.connect(ctx.destination); osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq * 1.08, now + start);
                osc.frequency.exponentialRampToValueAtTime(freq, now + start + 0.04);
                const t = now + start;
                gain.gain.setValueAtTime(0, t); gain.gain.linearRampToValueAtTime(vol, t + 0.008);
                gain.gain.setValueAtTime(vol, t + dur * 0.3);
                gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
                osc.start(t); osc.stop(t + dur + 0.02);
            });
            // Victory ding
            [
                { freq: 2093, start: 0.55, dur: 0.5, vol: 0.8 },
                { freq: 2637, start: 0.68, dur: 0.6, vol: 0.9 },
                { freq: 3136, start: 0.82, dur: 0.8, vol: 1.0 },
            ].forEach(({ freq, start, dur, vol }) => {
                const osc = ctx.createOscillator(); const gain = ctx.createGain();
                osc.connect(gain); gain.connect(ctx.destination);
                osc.type = 'sine'; osc.frequency.value = freq;
                const t = now + start;
                gain.gain.setValueAtTime(0, t); gain.gain.linearRampToValueAtTime(vol, t + 0.005);
                gain.gain.setValueAtTime(vol, t + 0.02); gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
                osc.start(t); osc.stop(t + dur);
                const osc2 = ctx.createOscillator(); const gain2 = ctx.createGain();
                osc2.connect(gain2); gain2.connect(ctx.destination);
                osc2.type = 'sine'; osc2.frequency.value = freq * 2.76;
                gain2.gain.setValueAtTime(0, t); gain2.gain.linearRampToValueAtTime(vol * 0.3, t + 0.005);
                gain2.gain.exponentialRampToValueAtTime(0.001, t + dur * 0.6);
                osc2.start(t); osc2.stop(t + dur * 0.6);
            });
        };
        if (ctx.state === 'suspended') ctx.resume().then(play).catch(() => { }); else play();
    } catch (e) { console.warn('Audio failed:', e); }
};

const triggerPaymentAlert = (data) => { showOSNotification(data); playBeepSound(); };

// ── Delete confirm modal ───────────────────────────────────────
const DeleteConfirmModal = ({ orderNumber, tid, onConfirm, onCancel, loading }) => (
    <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[10002] flex items-center justify-center bg-black/60 backdrop-blur-sm px-4"
        onClick={onCancel}
    >
        <motion.div
            initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.85, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 260 }}
            className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm"
            onClick={e => e.stopPropagation()}
        >
            <div className="text-center mb-5">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                </div>
                <h3 className="text-lg font-black text-gray-900">Delete Order?</h3>
                <p className="text-sm text-gray-500 mt-1">
                    Permanently deletes order <span className="font-bold text-gray-800">#{orderNumber}</span> and its linked transaction.
                </p>
                {tid && <p className="text-xs text-gray-400 font-mono mt-1 break-all">TID: {tid}</p>}
                <p className="text-xs text-red-500 mt-2 font-semibold">⚠️ This cannot be undone.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
                <button onClick={onCancel} disabled={loading}
                    className="py-3 rounded-xl font-bold text-sm border-2 border-gray-300 text-gray-600 hover:bg-gray-50 disabled:opacity-50 transition-all">
                    Cancel
                </button>
                <button onClick={onConfirm} disabled={loading}
                    className="py-3 rounded-xl font-bold text-sm bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 transition-all shadow-lg">
                    {loading ? (
                        <span className="flex items-center justify-center gap-1.5">
                            <span className="animate-spin h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full" />
                            Deleting...
                        </span>
                    ) : '🗑️ Delete'}
                </button>
            </div>
        </motion.div>
    </motion.div>
);

// ── Single notification card ───────────────────────────────────
const NotificationCard = ({ notification, onDismiss }) => {
    const [loading, setLoading] = useState(null);
    const [done, setDone] = useState(null);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [deleteLoading, setDeleteLoading] = useState(false);

    const handleApprove = async () => {
        setLoading('approve');
        try {
            await paymentService.approvePayment(notification.tid);
            setDone('approved');
            setTimeout(() => onDismiss(notification.tid), 2200);
        } catch (err) {
            alert('Failed to approve: ' + (err.message || err.error || 'Unknown error'));
            setLoading(null);
        }
    };

    const handleReject = async () => {
        if (!window.confirm('Reject this payment? Customer will be notified.')) return;
        setLoading('reject');
        try {
            await paymentService.rejectPayment(notification.tid);
            setDone('rejected');
            setTimeout(() => onDismiss(notification.tid), 2200);
        } catch (err) {
            alert('Failed to reject: ' + (err.message || err.error || 'Unknown error'));
            setLoading(null);
        }
    };

    const handleDeleteConfirm = async () => {
        setDeleteLoading(true);
        try {
            if (notification.orderId) {
                await fetch(
                    `${import.meta.env.VITE_API_URL}/order/order/${notification.orderId}`,
                    { method: 'DELETE', credentials: 'include' }
                );
            } else {
                await paymentService.deleteTransaction(notification.tid);
            }
            setDone('deleted');
            setTimeout(() => onDismiss(notification.tid), 1800);
        } catch (err) {
            alert('Failed to delete: ' + (err.message || err.error || 'Unknown error'));
            setDeleteLoading(false);
        }
        setShowDeleteModal(false);
    };

    const timeAgo = (dateStr) => {
        const diff = Math.floor((Date.now() - new Date(dateStr)) / 1000);
        if (diff < 60) return `${diff}s ago`;
        if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
        return `${Math.floor(diff / 3600)}h ago`;
    };

    return (
        <>
            <AnimatePresence>
                {showDeleteModal && (
                    <DeleteConfirmModal
                        orderNumber={notification.orderNumber}
                        tid={notification.tid}
                        onConfirm={handleDeleteConfirm}
                        onCancel={() => setShowDeleteModal(false)}
                        loading={deleteLoading}
                    />
                )}
            </AnimatePresence>

            <motion.div
                initial={{ x: 420, opacity: 0, scale: 0.92 }}
                animate={{ x: 0, opacity: 1, scale: 1 }}
                exit={{ x: 420, opacity: 0, scale: 0.92 }}
                transition={{ type: 'spring', damping: 22, stiffness: 240 }}
                className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden w-96 max-w-[calc(100vw-2rem)]"
                style={{ boxShadow: '0 24px 64px rgba(0,0,0,0.18)' }}
            >
                {/* Header */}
                <div className="bg-gradient-to-r from-purple-600 to-indigo-600 px-5 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-300 opacity-80" />
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-400" />
                        </span>
                        <span className="text-white font-bold text-sm tracking-wide">💰 New Payment Alert!</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-purple-200 text-xs">{timeAgo(notification.createdAt || new Date())}</span>
                        <button onClick={playBeepSound} title="Replay sound"
                            className="text-purple-200 hover:text-yellow-300 transition-colors">🔊</button>
                        <button onClick={() => setShowDeleteModal(true)} title="Delete order" disabled={!!done}
                            className="text-purple-200 hover:text-red-300 transition-colors text-sm">🗑️</button>
                        <button onClick={() => onDismiss(notification.tid)}
                            className="text-purple-200 hover:text-white transition-colors text-xl font-bold leading-none">✕</button>
                    </div>
                </div>

                {/* Done state */}
                {done ? (
                    <div className={`p-8 text-center ${done === 'approved' ? 'bg-green-50' : done === 'deleted' ? 'bg-gray-50' : 'bg-red-50'}`}>
                        <div className="text-5xl mb-3">
                            {done === 'approved' ? '✅' : done === 'deleted' ? '🗑️' : '❌'}
                        </div>
                        <p className={`font-bold text-xl ${done === 'approved' ? 'text-green-700' : done === 'deleted' ? 'text-gray-600' : 'text-red-700'}`}>
                            {done === 'approved' ? 'Payment Approved!' : done === 'deleted' ? 'Order Deleted' : 'Payment Rejected'}
                        </p>
                        <p className="text-sm text-gray-400 mt-1">
                            {done === 'deleted' ? 'Order and transaction removed.' : 'Customer will be notified automatically.'}
                        </p>
                    </div>
                ) : (
                    <div className="p-5">
                        {/* Amount + Customer */}
                        <div className="flex items-start justify-between mb-4">
                            <div>
                                <h3 className="font-bold text-gray-900 text-base">{notification.userName}</h3>
                                <p className="text-xs text-gray-500 mt-0.5">📱 {notification.phone}</p>
                                <p className="text-xs text-gray-500 mt-0.5">
                                    Order: <span className="font-mono font-semibold text-gray-700">{notification.orderNumber}</span>
                                </p>
                                <p className="text-xs text-gray-400 font-mono mt-0.5 break-all">TID: {notification.tid}</p>
                            </div>
                            <div className="text-right flex-shrink-0 ml-3">
                                <div className="text-2xl font-black text-green-600">
                                    ₹{Number(notification.totalAmount)?.toLocaleString('en-IN')}
                                </div>
                                <span className={`text-xs px-2 py-1 rounded-full font-semibold ${notification.payType === 'phonepe' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                                    {notification.payType?.toUpperCase()}
                                </span>
                            </div>
                        </div>

                        {/* Address */}
                        <div className="bg-gray-50 rounded-xl p-3 mb-4">
                            <p className="text-xs font-semibold text-gray-500 mb-1">📍 DELIVERY ADDRESS</p>
                            <p className="text-sm text-gray-700 leading-snug">
                                {notification.address?.address}, {notification.address?.city}, {notification.address?.state} — {notification.address?.pincode}
                            </p>
                        </div>

                        {/* Products */}
                        {notification.products?.length > 0 && (
                            <div className="mb-5">
                                <p className="text-xs font-semibold text-gray-500 mb-2">🛒 PRODUCTS ({notification.products.length})</p>
                                <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                                    {notification.products.map((p, i) => (
                                        <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2">
                                            {p.image && <img src={p.image} alt={p.name} className="w-8 h-8 rounded object-cover flex-shrink-0 border" onError={e => e.target.style.display = 'none'} />}
                                            <div className="flex-1 min-w-0">
                                                <p className="text-xs font-medium text-gray-800 truncate">{p.name}</p>
                                                <p className="text-xs text-gray-500">Qty: {p.quantity} × ₹{p.price}</p>
                                            </div>
                                            <p className="text-xs font-bold text-gray-700 flex-shrink-0">
                                                ₹{(p.quantity * p.price).toLocaleString('en-IN')}
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* 3-button action row */}
                        <div className="grid grid-cols-3 gap-2">
                            <button onClick={handleReject} disabled={!!loading}
                                className="py-3 rounded-xl font-bold text-xs border-2 border-red-500 text-red-600 hover:bg-red-50 disabled:opacity-50 transition-all">
                                {loading === 'reject' ? (
                                    <span className="flex items-center justify-center gap-1">
                                        <span className="animate-spin h-3 w-3 border-2 border-red-400 border-t-transparent rounded-full" />
                                    </span>
                                ) : '❌ Reject'}
                            </button>
                            <button onClick={handleApprove} disabled={!!loading}
                                className="py-3 rounded-xl font-bold text-xs bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 transition-all shadow-lg">
                                {loading === 'approve' ? (
                                    <span className="flex items-center justify-center gap-1">
                                        <span className="animate-spin h-3 w-3 border-2 border-white border-t-transparent rounded-full" />
                                    </span>
                                ) : '✅ Approve'}
                            </button>
                            <button onClick={() => setShowDeleteModal(true)} disabled={!!loading}
                                className="py-3 rounded-xl font-bold text-xs border-2 border-gray-300 text-gray-500 hover:bg-red-50 hover:border-red-300 hover:text-red-600 disabled:opacity-50 transition-all">
                                🗑️ Delete
                            </button>
                        </div>
                    </div>
                )}

                {/* Auto-dismiss progress bar (2 minutes) */}
                <motion.div
                    className="h-1 bg-gradient-to-r from-purple-500 to-indigo-500"
                    initial={{ scaleX: 1, originX: 0 }}
                    animate={{ scaleX: 0 }}
                    transition={{ duration: 120, ease: 'linear' }}
                    onAnimationComplete={() => onDismiss(notification.tid)}
                />
            </motion.div>
        </>
    );
};

// ── MAIN EXPORT ────────────────────────────────────────────────
const AdminPaymentNotification = () => {
    const [notifications, setNotifications] = useState([]);
    const [permissionStatus, setPermissionStatus] = useState('default');
    const [showPermBanner, setShowPermBanner] = useState(false);
    const socketRef = useRef(null);

    useEffect(() => {
        const init = async () => {
            const status = await requestNotificationPermission();
            setPermissionStatus(status);
            if (status !== 'granted') setShowPermBanner(true);
        };
        init();
        const unlock = () => { unlockAudioCtx(); };
        document.addEventListener('click', unlock, { once: true });
        document.addEventListener('keydown', unlock, { once: true });
        document.addEventListener('touchstart', unlock, { once: true, passive: true });
        return () => {
            document.removeEventListener('click', unlock);
            document.removeEventListener('keydown', unlock);
            document.removeEventListener('touchstart', unlock);
        };
    }, []);

    useEffect(() => {
        socketRef.current = io(SOCKET_URL, {
            transports: ['websocket', 'polling'],
            reconnection: true, reconnectionAttempts: 20,
            reconnectionDelay: 2000, withCredentials: true,
        });

        socketRef.current.on('connect', () => {
            console.log('🔌 Admin socket connected');
            socketRef.current.emit('admin_join');
        });

        socketRef.current.on('new_payment_initiated', (data) => {
            console.log('🔔 New payment:', data);
            triggerPaymentAlert(data);
            setNotifications(prev => [{ ...data, _localId: Date.now() }, ...prev.slice(0, 4)]);
        });

        socketRef.current.on('payment_approved', ({ tid }) =>
            setNotifications(prev => prev.filter(n => n.tid !== tid)));

        socketRef.current.on('payment_rejected', ({ tid }) =>
            setNotifications(prev => prev.filter(n => n.tid !== tid)));

        return () => { socketRef.current?.disconnect(); };
    }, []);

    const dismissNotification = (tid) =>
        setNotifications(prev => prev.filter(n => n.tid !== tid));

    const handleRequestPermission = async () => {
        const status = await requestNotificationPermission();
        setPermissionStatus(status);
        if (status === 'granted') {
            setShowPermBanner(false);
            new Notification('✅ Notifications enabled!', {
                body: 'You will now receive payment alerts even in background tabs.',
                icon: '/favicon.ico'
            });
        }
    };

    return (
        <>
            {/* Browser notification permission banner */}
            <AnimatePresence>
                {showPermBanner && permissionStatus !== 'granted' && (
                    <motion.div
                        initial={{ y: -60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -60, opacity: 0 }}
                        className="fixed top-0 left-0 right-0 z-[10001] bg-indigo-600 text-white px-4 py-3 flex items-center justify-between shadow-lg"
                    >
                        <div className="flex items-center gap-3">
                            <span className="text-xl">🔔</span>
                            <div>
                                <p className="font-bold text-sm">Enable browser notifications</p>
                                <p className="text-indigo-200 text-xs">
                                    {permissionStatus === 'denied'
                                        ? 'Go to browser Site Settings and allow notifications.'
                                        : 'Get alerts even when this tab is in the background.'}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0 ml-4">
                            {permissionStatus !== 'denied' && (
                                <button onClick={handleRequestPermission}
                                    className="bg-white text-indigo-700 font-bold text-sm px-4 py-2 rounded-lg hover:bg-indigo-50 transition-colors">
                                    Enable
                                </button>
                            )}
                            <button onClick={() => setShowPermBanner(false)} className="text-indigo-200 hover:text-white text-xl font-bold">✕</button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Notification stack — top-right corner */}
            <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-3 pointer-events-none"
                style={{ maxHeight: 'calc(100vh - 5rem)', overflowY: 'auto', overflowX: 'visible' }}>
                <AnimatePresence mode="popLayout">
                    {notifications.map(notification => (
                        <div key={notification.tid} className="pointer-events-auto">
                            <NotificationCard notification={notification} onDismiss={dismissNotification} />
                        </div>
                    ))}
                </AnimatePresence>
            </div>
        </>
    );
};

export default AdminPaymentNotification;