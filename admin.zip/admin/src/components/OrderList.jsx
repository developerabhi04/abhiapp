import { useState, useEffect } from 'react';
import orderService from '../services/orderService';

/* ── CSV writer — opens in Excel with no corruption warning ── */
const toCSV = (rows) => {
    const headers = [
        'S.No', 'Order Number', 'Date', 'Products', 'Total Items',
        'Total Amount (Rs)', 'Delivery Fee (Rs)', 'Coupon Code', 'Coupon Discount (Rs)',
        'Payment Method', 'Payment Status', 'Order Status', 'Order Source',
        'Customer Name', 'Phone', 'Address', 'City', 'State', 'Pincode'
    ];

    const escCSV = (v) => {
        const str = String(v ?? '');
        const escaped = str.replace(/"/g, '""');
        return (escaped.includes(',') || escaped.includes('\n') || escaped.includes('"'))
            ? `"${escaped}"`
            : escaped;
    };

    const lines = [
        headers.map(escCSV).join(','),
        ...rows.map((order, i) => {
            const products = order.products?.map(p =>
                `${p.name} x${p.quantity} @Rs${p.dmartPrice}`
            ).join(' | ') || '';

            const date = order.createdAt
                ? new Date(order.createdAt).toLocaleString('en-IN', {
                    year: 'numeric', month: 'short', day: 'numeric',
                    hour: '2-digit', minute: '2-digit'
                })
                : '';

            return [
                order._sno ?? i + 1,
                order.orderNumber || '',
                date,
                products,
                order.orderSummary?.totalItems ?? '',
                order.orderSummary?.finalTotal ?? '',
                order.orderSummary?.deliveryFee ?? '',
                order.couponUsed?.code || '',
                order.couponUsed?.discount || '',
                (order.paymentMethod || '').toUpperCase(),
                (order.paymentStatus || '').toUpperCase(),
                (order.status || '').toUpperCase(),
                order.dataSource === 'cart' ? 'Cart' : 'Buy Now',
                order.deliveryAddress?.fullName || '',
                order.deliveryAddress?.phone || '',
                order.deliveryAddress?.address || '',
                order.deliveryAddress?.city || '',
                order.deliveryAddress?.state || '',
                order.deliveryAddress?.pincode || '',
            ].map(escCSV).join(',');
        })
    ];

    // \uFEFF = UTF-8 BOM so Excel shows Indian names/characters correctly
    return new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
};

const OrderList = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [pagination, setPagination] = useState({});
    const [filters, setFilters] = useState({ page: 1, limit: 20, status: '' });

    const [dlFrom, setDlFrom] = useState('');
    const [dlTo, setDlTo] = useState('');
    const [isDownloading, setIsDownloading] = useState(false);
    const [dlError, setDlError] = useState('');

    useEffect(() => { fetchOrders(); }, [filters]);

    const fetchOrders = async () => {
        try {
            setLoading(true);
            const response = await orderService.getAllOrders(filters);
            if (response.success) {
                setOrders(response.data);
                setPagination(response.pagination);
            } else {
                setError('Failed to fetch orders');
            }
        } catch (error) {
            setError(error.message || 'Failed to fetch orders');
        } finally {
            setLoading(false);
        }
    };

    const handleDeleteOrder = async (orderId, orderNumber) => {
        if (!window.confirm(`Delete order "${orderNumber}"?`)) return;
        try {
            const response = await orderService.deleteOrder(orderId);
            if (response.success) { fetchOrders(); alert('Order deleted!'); }
            else alert('Failed to delete order');
        } catch (error) {
            alert(error.message || 'Failed to delete order');
        }
    };

    const handleFilterChange = (key, value) => {
        setFilters(prev => ({ ...prev, [key]: value, ...(key !== 'page' && { page: 1 }) }));
    };

    /* ── Serial number: global across pages ── */
    const serialOf = (indexInPage) => {
        const perPage = parseInt(filters.limit) || 20;
        const currentPage = pagination.currentPage || filters.page;
        return (currentPage - 1) * perPage + indexInPage + 1;
    };

    /* ── Range Download → CSV (opens in Excel perfectly) ── */
    const handleDownload = async () => {
        setDlError('');
        const from = parseInt(dlFrom);
        const to = parseInt(dlTo);
        const total = pagination.totalOrders || 0;

        if (!dlFrom || !dlTo) return setDlError('Please enter both From and To values.');
        if (isNaN(from) || isNaN(to)) return setDlError('Only numbers allowed.');
        if (from < 1) return setDlError('From must be at least 1.');
        if (to > total) return setDlError(`To cannot exceed total orders (${total}).`);
        if (from > to) return setDlError('From must be less than or equal to To.');

        setIsDownloading(true);
        try {
            const allResponse = await orderService.getAllOrders({ page: 1, limit: total, status: filters.status });
            if (!allResponse.success) throw new Error('Failed to fetch orders for download');

            const sliced = allResponse.data.slice(from - 1, to);

            // Attach correct S.No (1-based, matches table serial)
            const blob = toCSV(sliced.map((o, i) => ({ ...o, _sno: from + i })));
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `orders_${from}_to_${to}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (err) {
            setDlError(err.message || 'Download failed');
        } finally {
            setIsDownloading(false);
        }
    };

    /* ── Status badge colours ── */
    const statusColor = (status) => {
        const map = {
            delivered: 'bg-green-100 text-green-800',
            confirmed: 'bg-blue-100 text-blue-800',
            shipped: 'bg-indigo-100 text-indigo-800',
            processing: 'bg-purple-100 text-purple-800',
            cancelled: 'bg-red-100 text-red-800',
            pending: 'bg-yellow-100 text-yellow-800',
            paid: 'bg-green-100 text-green-800',
            failed: 'bg-red-100 text-red-800',
            cod: 'bg-orange-100 text-orange-800',
            online: 'bg-purple-100 text-purple-800',
        };
        return map[status?.toLowerCase()] || 'bg-gray-100 text-gray-700';
    };

    /* ── Loading ── */
    if (loading) return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="flex items-center gap-2">
                <svg className="animate-spin h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                <span className="text-gray-600 text-lg">Loading orders...</span>
            </div>
        </div>
    );

    /* ── Error ── */
    if (error) return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-6 flex items-center gap-3">
                <svg className="w-6 h-6 text-red-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <span className="text-red-700 font-medium">Error: {error}</span>
            </div>
        </div>
    );

    return (
        <div className="min-h-screen bg-gray-50 py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

                {/* ── Header ── */}
                <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Order Management</h1>
                        <p className="text-sm text-gray-500 mt-0.5">All customer orders — Cash on Delivery</p>
                    </div>
                    <span className="bg-white border border-gray-200 rounded-lg px-4 py-2 text-sm text-gray-500 shadow-sm">
                        Total Orders: <span className="font-bold text-gray-900">{pagination.totalOrders || 0}</span>
                    </span>
                </div>

                {/* ── Filters + Download ── */}
                <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">

                        {/* Status Filter */}
                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1.5">Filter by Status</label>
                            <select
                                value={filters.status}
                                onChange={e => handleFilterChange('status', e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            >
                                <option value="">All Status</option>
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="processing">Processing</option>
                                <option value="shipped">Shipped</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>

                        {/* Per Page */}
                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1.5">Items per page</label>
                            <select
                                value={filters.limit}
                                onChange={e => handleFilterChange('limit', e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            >
                                <option value="10">10</option>
                                <option value="20">20</option>
                                <option value="50">50</option>
                            </select>
                        </div>

                        {/* Refresh */}
                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1.5">&nbsp;</label>
                            <button
                                onClick={fetchOrders}
                                className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors text-sm flex items-center justify-center gap-2"
                            >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                </svg>
                                Refresh
                            </button>
                        </div>

                        {/* ── Range Download ── */}
                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1.5">
                                Download as CSV / Excel&nbsp;
                                <span className="text-gray-400 font-normal">(1 – {pagination.totalOrders || 0})</span>
                            </label>
                            <div className="flex gap-2 items-center">
                                <input
                                    type="number" min="1" max={pagination.totalOrders}
                                    value={dlFrom}
                                    onChange={e => { setDlFrom(e.target.value); setDlError(''); }}
                                    placeholder="From"
                                    className="w-20 px-2 py-2 border border-gray-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-green-500 focus:border-transparent"
                                />
                                <span className="text-gray-400 text-sm">–</span>
                                <input
                                    type="number" min="1" max={pagination.totalOrders}
                                    value={dlTo}
                                    onChange={e => { setDlTo(e.target.value); setDlError(''); }}
                                    placeholder="To"
                                    className="w-20 px-2 py-2 border border-gray-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-green-500 focus:border-transparent"
                                />
                                <button
                                    onClick={handleDownload}
                                    disabled={isDownloading}
                                    className="flex-1 bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm flex items-center justify-center gap-1.5 whitespace-nowrap"
                                >
                                    {isDownloading ? (
                                        <>
                                            <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                                            </svg>
                                            Downloading…
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                            </svg>
                                            ⬇ Download
                                        </>
                                    )}
                                </button>
                            </div>
                            {dlError && <p className="text-red-500 text-xs mt-1">{dlError}</p>}
                        </div>
                    </div>
                </div>

                {/* ── Orders Table ── */}
                <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200 text-sm">
                            <thead className="bg-gray-50 text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <tr>
                                    <th className="px-3 py-3 text-center w-12">#</th>
                                    <th className="px-5 py-3 text-left">Order & Products</th>
                                    <th className="px-5 py-3 text-left">Payment</th>
                                    <th className="px-5 py-3 text-left">Delivery Address</th>
                                    <th className="px-5 py-3 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {orders.map((order, idx) => (
                                    <tr key={order._id} className="hover:bg-gray-50 transition-colors">

                                        {/* ── S.No ── */}
                                        <td className="px-3 py-4 align-top text-center">
                                            <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold">
                                                {serialOf(idx)}
                                            </span>
                                        </td>

                                        {/* ── Order & Products ── */}
                                        <td className="px-5 py-4 align-top">
                                            <div className="font-semibold text-gray-900">#{order.orderNumber}</div>
                                            <div className="text-xs text-gray-400 mb-2">
                                                {new Date(order.createdAt).toLocaleDateString('en-IN', {
                                                    year: 'numeric', month: 'short', day: 'numeric',
                                                    hour: '2-digit', minute: '2-digit'
                                                })}
                                            </div>
                                            <div className="space-y-1">
                                                {order.products?.map((product, i) => (
                                                    <div key={i} className="text-xs text-gray-600 bg-gray-50 rounded px-2 py-1">
                                                        <div className="flex items-center justify-between">
                                                            <span className="font-medium">{product.name}</span>
                                                            <span className="bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded">×{product.quantity}</span>
                                                        </div>
                                                        <div className="text-gray-400 mt-0.5">₹{product.dmartPrice} each → ₹{product.totalPrice}</div>
                                                    </div>
                                                ))}
                                            </div>
                                            <div className="mt-2 text-sm font-semibold text-green-700 bg-green-50 rounded px-2 py-1">
                                                Total: ₹{order.orderSummary?.finalTotal}
                                                <span className="font-normal text-green-600"> ({order.orderSummary?.totalItems} items)</span>
                                            </div>
                                            {order.orderSummary?.totalSavings > 0 && (
                                                <div className="text-xs text-green-600 mt-0.5 px-2">
                                                    Saved: ₹{order.orderSummary.totalSavings}
                                                </div>
                                            )}
                                        </td>

                                        {/* ── Payment ── */}
                                        <td className="px-5 py-4 align-top">
                                            <div className="space-y-2">
                                                <div className="flex items-center justify-between gap-2">
                                                    <span className="text-xs text-gray-500">Method</span>
                                                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColor(order.paymentMethod)}`}>
                                                        {order.paymentMethod?.toUpperCase() === 'COD' ? '💵 COD' : order.paymentMethod?.toUpperCase()}
                                                    </span>
                                                </div>
                                                <div className="flex items-center justify-between gap-2">
                                                    <span className="text-xs text-gray-500">Payment</span>
                                                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColor(order.paymentStatus)}`}>
                                                        {order.paymentStatus?.toUpperCase()}
                                                    </span>
                                                </div>
                                                <div className="flex items-center justify-between gap-2">
                                                    <span className="text-xs text-gray-500">Status</span>
                                                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColor(order.status)}`}>
                                                        {order.status?.toUpperCase()}
                                                    </span>
                                                </div>
                                                <div className="flex items-center justify-between gap-2">
                                                    <span className="text-xs text-gray-500">Source</span>
                                                    <span className="text-xs text-gray-700">
                                                        {order.dataSource === 'cart' ? '🛒 Cart' : '⚡ Buy Now'}
                                                    </span>
                                                </div>
                                                {order.couponUsed?.code && (
                                                    <div className="flex items-center justify-between gap-2 border-t pt-2 mt-1">
                                                        <span className="text-xs text-gray-500">Coupon</span>
                                                        <div className="text-right">
                                                            <div className="text-xs font-semibold text-orange-600">{order.couponUsed.code}</div>
                                                            <div className="text-xs text-green-600">-₹{order.couponUsed.discount}</div>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        </td>

                                        {/* ── Delivery Address ── */}
                                        <td className="px-5 py-4 align-top">
                                            <div className="space-y-1 text-sm">
                                                <div className="font-semibold text-gray-900">{order.deliveryAddress?.fullName}</div>
                                                <a href={`tel:${order.deliveryAddress?.phone}`} className="text-blue-600 hover:underline text-sm block">
                                                    📞 {order.deliveryAddress?.phone}
                                                </a>
                                                <div className="text-xs text-gray-600 bg-gray-50 rounded p-2 leading-relaxed mt-1">
                                                    {order.deliveryAddress?.address}<br />
                                                    {order.deliveryAddress?.city}, {order.deliveryAddress?.state}<br />
                                                    PIN: {order.deliveryAddress?.pincode}
                                                </div>
                                                <button
                                                    onClick={() => {
                                                        const q = `${order.deliveryAddress?.address}, ${order.deliveryAddress?.city}, ${order.deliveryAddress?.state} ${order.deliveryAddress?.pincode}`;
                                                        window.open(`https://maps.google.com/maps?q=${encodeURIComponent(q)}`, '_blank');
                                                    }}
                                                    className="text-xs text-blue-500 hover:text-blue-700 flex items-center gap-1 mt-1"
                                                >
                                                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                                    </svg>
                                                    View on Maps
                                                </button>
                                            </div>
                                        </td>

                                        {/* ── Actions ── */}
                                        <td className="px-5 py-4 align-top">
                                            <button
                                                onClick={() => handleDeleteOrder(order._id, order.orderNumber)}
                                                className="text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 px-3 py-2 rounded-lg transition-colors text-xs flex items-center gap-1.5 whitespace-nowrap"
                                            >
                                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Empty State */}
                    {orders.length === 0 && (
                        <div className="text-center py-12">
                            <svg className="mx-auto h-10 w-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                            </svg>
                            <h3 className="mt-2 text-sm font-medium text-gray-900">No orders found</h3>
                            <p className="mt-1 text-xs text-gray-500">
                                {filters.status ? `No orders with status "${filters.status}"` : 'No orders have been placed yet.'}
                            </p>
                        </div>
                    )}

                    {/* Pagination */}
                    {pagination.totalPages > 1 && (
                        <div className="px-5 py-3 border-t border-gray-200 flex items-center justify-between text-sm">
                            <p className="text-gray-500">
                                Page <span className="font-medium text-gray-900">{pagination.currentPage}</span> of{' '}
                                <span className="font-medium text-gray-900">{pagination.totalPages}</span>
                                <span className="text-gray-400"> ({pagination.totalOrders} orders)</span>
                            </p>
                            <div className="flex gap-2">
                                <button
                                    disabled={!pagination.hasPrevPage}
                                    onClick={() => handleFilterChange('page', filters.page - 1)}
                                    className="px-3 py-1.5 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                                    </svg>
                                    Prev
                                </button>
                                <button
                                    disabled={!pagination.hasNextPage}
                                    onClick={() => handleFilterChange('page', filters.page + 1)}
                                    className="px-3 py-1.5 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1"
                                >
                                    Next
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    )}
                </div>

            </div>
        </div>
    );
};

export default OrderList;