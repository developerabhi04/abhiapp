import { useState, useEffect, useCallback } from 'react';
import paymentService from '../services/paymentService';

const STATUS_CONFIG = {
    pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800 border-yellow-300', dot: 'bg-yellow-500' },
    success: { label: 'Paid', color: 'bg-green-100 text-green-800 border-green-300', dot: 'bg-green-500' },
    failed: { label: 'Failed', color: 'bg-red-100 text-red-800 border-red-300', dot: 'bg-red-500' },
    expired: { label: 'Expired', color: 'bg-gray-100 text-gray-600 border-gray-300', dot: 'bg-gray-400' },
};

const StatusBadge = ({ status }) => {
    const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.expired;
    return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border ${cfg.color}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
            {cfg.label}
        </span>
    );
};

const DeleteConfirmModal = ({ transaction, onConfirm, onCancel, loading }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
        <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm">
            <div className="text-center mb-5">
                <div className="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg className="w-7 h-7 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                </div>
                <h3 className="text-base font-black text-gray-900">Delete Transaction?</h3>
                <p className="text-sm text-gray-500 mt-1">
                    Order <span className="font-bold">{transaction?.orderId?.orderNumber || 'N/A'}</span>
                </p>
                <p className="text-xs font-mono text-gray-400 mt-1 break-all">TID: {transaction?.tid}</p>
                <p className="text-xs text-red-500 mt-2 font-semibold">⚠️ Also deletes the linked order. Cannot be undone.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
                <button onClick={onCancel} disabled={loading}
                    className="py-2.5 rounded-xl font-bold text-sm border-2 border-gray-200 hover:bg-gray-50 disabled:opacity-50">Cancel</button>
                <button onClick={onConfirm} disabled={loading}
                    className="py-2.5 rounded-xl font-bold text-sm bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 shadow-md">
                    {loading ? 'Deleting...' : '🗑️ Delete'}
                </button>
            </div>
        </div>
    </div>
);

const TransactionHistory = () => {
    const [transactions, setTransactions] = useState([]);
    const [pagination, setPagination] = useState({});
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState({});
    const [error, setError] = useState(null);
    const [filterStatus, setFilterStatus] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [expandedRow, setExpandedRow] = useState(null);
    const [deleteModal, setDeleteModal] = useState({ open: false, transaction: null, loading: false });

    const loadTransactions = useCallback(async () => {
        setLoading(true); setError(null);
        try {
            const params = { page: currentPage, limit: 20 };
            if (filterStatus) params.status = filterStatus;
            const res = await paymentService.getAllTransactions(params);
            setTransactions(res.data || []);
            setPagination(res.pagination || {});
        } catch (err) {
            setError(err.message || err.error || 'Failed to load transactions');
        } finally { setLoading(false); }
    }, [currentPage, filterStatus]);

    useEffect(() => { loadTransactions(); }, [loadTransactions]);

    const handleApprove = async (tid) => {
        setActionLoading(p => ({ ...p, [tid]: 'approve' }));
        try {
            await paymentService.approvePayment(tid);
            setTransactions(prev => prev.map(t =>
                t.tid === tid ? { ...t, status: 'success', completedAt: new Date().toISOString() } : t));
        } catch (err) { alert(err.message || err.error || 'Failed to approve'); }
        finally { setActionLoading(p => { const n = { ...p }; delete n[tid]; return n; }); }
    };

    const handleReject = async (tid) => {
        if (!window.confirm('Reject this payment?')) return;
        setActionLoading(p => ({ ...p, [tid]: 'reject' }));
        try {
            await paymentService.rejectPayment(tid);
            setTransactions(prev => prev.map(t =>
                t.tid === tid ? { ...t, status: 'failed', completedAt: new Date().toISOString() } : t));
        } catch (err) { alert(err.message || err.error || 'Failed to reject'); }
        finally { setActionLoading(p => { const n = { ...p }; delete n[tid]; return n; }); }
    };

    const openDeleteModal = (transaction) =>
        setDeleteModal({ open: true, transaction, loading: false });
    const closeDeleteModal = () =>
        setDeleteModal({ open: false, transaction: null, loading: false });

    const handleDeleteConfirm = async () => {
        setDeleteModal(p => ({ ...p, loading: true }));
        const txn = deleteModal.transaction;
        try {
            const orderId = txn?.orderId?._id || txn?.orderId;
            if (orderId) {
                await fetch(`${import.meta.env.VITE_API_URL}/order/order/${orderId}`,
                    { method: 'DELETE', credentials: 'include' });
            } else {
                await paymentService.deleteTransaction(txn.tid);
            }
            setTransactions(prev => prev.filter(t => t.tid !== txn.tid));
            closeDeleteModal();
        } catch (err) {
            alert(err.message || err.error || 'Delete failed');
            setDeleteModal(p => ({ ...p, loading: false }));
        }
    };

    const formatDate = (d) => {
        if (!d) return '—';
        const dt = new Date(d);
        return `${dt.toLocaleDateString('en-IN')} ${dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`;
    };

    const pendingCount = transactions.filter(t => t.status === 'pending').length;

    return (
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
            {deleteModal.open && (
                <DeleteConfirmModal transaction={deleteModal.transaction}
                    onConfirm={handleDeleteConfirm} onCancel={closeDeleteModal} loading={deleteModal.loading} />
            )}

            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
                <div>
                    <h1 className="text-2xl font-black text-gray-900 flex items-center gap-2">
                        💳 Transaction History
                        {pendingCount > 0 && (
                            <span className="bg-red-500 text-white text-xs font-bold rounded-full px-2 py-0.5 animate-pulse">
                                {pendingCount} Pending
                            </span>
                        )}
                    </h1>
                    <p className="text-sm text-gray-500 mt-0.5">Total: {pagination.total || 0} transactions</p>
                </div>
                <div className="flex items-center gap-2">
                    <select value={filterStatus}
                        onChange={e => { setFilterStatus(e.target.value); setCurrentPage(1); }}
                        className="text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                        <option value="">All Status</option>
                        <option value="pending">Pending</option>
                        <option value="success">Paid</option>
                        <option value="failed">Failed</option>
                        <option value="expired">Expired</option>
                    </select>
                    <button onClick={loadTransactions}
                        className="text-sm border border-gray-200 rounded-lg px-3 py-2 hover:bg-gray-50 transition-colors" title="Refresh">🔄</button>
                </div>
            </div>

            {error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4 flex items-center gap-3">
                    <span className="text-red-500">⚠️</span>
                    <p className="text-red-700 text-sm font-medium">{error}</p>
                    <button onClick={loadTransactions} className="ml-auto text-sm text-red-600 hover:underline font-semibold">Retry</button>
                </div>
            )}

            {loading ? (
                <div className="space-y-3">
                    {[...Array(6)].map((_, i) => (
                        <div key={i} className="bg-white rounded-xl border border-gray-100 p-4 animate-pulse flex gap-4">
                            <div className="h-4 bg-gray-200 rounded w-28" />
                            <div className="h-4 bg-gray-200 rounded w-20" />
                            <div className="h-4 bg-gray-200 rounded w-16" />
                            <div className="h-4 bg-gray-200 rounded flex-1" />
                        </div>
                    ))}
                </div>
            ) : transactions.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
                    <p className="text-4xl mb-3">📭</p>
                    <p className="font-bold text-gray-500">No transactions found</p>
                    <p className="text-sm text-gray-400 mt-1">Try changing the filter above</p>
                </div>
            ) : (
                <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
                    {/* Desktop table */}
                    <div className="hidden md:block overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50 border-b border-gray-100">
                                <tr>
                                    {['TID / Order', 'Customer', 'Products', 'Amount', 'Method', 'Status', 'Created', 'Action'].map(h => (
                                        <th key={h} className="text-left text-xs font-bold text-gray-500 uppercase tracking-wider px-4 py-3">{h}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {transactions.map(txn => {
                                    const order = txn.orderId;
                                    const aLoad = actionLoading[txn.tid];
                                    return (
                                        <tr key={txn.tid} className={`hover:bg-gray-50 transition-colors ${txn.status === 'pending' ? 'bg-yellow-50/40' : ''}`}>
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <p className="font-mono text-xs font-semibold text-indigo-700 truncate max-w-[130px]">{txn.tid}</p>
                                                <p className="text-xs text-gray-400 mt-0.5">{order?.orderNumber || '—'}</p>
                                            </td>
                                            <td className="px-4 py-3">
                                                <p className="font-semibold text-gray-800 text-sm">{order?.deliveryAddress?.fullName || '—'}</p>
                                                <p className="text-xs text-gray-400">{order?.deliveryAddress?.phone || ''}</p>
                                            </td>
                                            <td className="px-4 py-3 max-w-[180px]">
                                                {order?.products?.slice(0, 2).map((p, i) => (
                                                    <p key={i} className="text-xs text-gray-600 truncate">{p.quantity}× {p.name}</p>
                                                ))}
                                                {order?.products?.length > 2 && <p className="text-xs text-gray-400">+{order.products.length - 2} more</p>}
                                                {!order?.products?.length && <p className="text-xs text-gray-400">—</p>}
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <span className="font-black text-base text-green-700">₹{Number(txn.amount).toLocaleString('en-IN')}</span>
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${txn.payType === 'phonepe' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                                                    {txn.payType?.toUpperCase()}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap"><StatusBadge status={txn.status} /></td>
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <p className="text-xs text-gray-500">{formatDate(txn.createdAt)}</p>
                                                {txn.completedAt && <p className="text-xs text-green-600">{formatDate(txn.completedAt)}</p>}
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <div className="flex items-center gap-1.5">
                                                    {txn.status === 'pending' && (
                                                        <>
                                                            <button onClick={() => handleApprove(txn.tid)} disabled={!!aLoad}
                                                                className="text-xs font-bold px-3 py-1.5 rounded-lg bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 transition-all shadow-sm">
                                                                {aLoad === 'approve' ? '...' : '✅ Approve'}
                                                            </button>
                                                            <button onClick={() => handleReject(txn.tid)} disabled={!!aLoad}
                                                                className="text-xs font-bold px-3 py-1.5 rounded-lg border-2 border-red-400 text-red-600 hover:bg-red-50 disabled:opacity-50 transition-all">
                                                                {aLoad === 'reject' ? '...' : 'Reject'}
                                                            </button>
                                                        </>
                                                    )}
                                                    <button onClick={() => openDeleteModal(txn)} disabled={!!aLoad}
                                                        className="text-xs font-bold p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 disabled:opacity-40 transition-all" title="Delete">
                                                        🗑️
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>

                    {/* Mobile cards */}
                    <div className="md:hidden divide-y divide-gray-100">
                        {transactions.map(txn => {
                            const order = txn.orderId;
                            const aLoad = actionLoading[txn.tid];
                            const isOpen = expandedRow === txn.tid;
                            return (
                                <div key={txn.tid} className={`p-4 ${txn.status === 'pending' ? 'bg-yellow-50/40' : ''}`}>
                                    <div className="flex items-start justify-between mb-2 gap-2">
                                        <div className="flex-1 min-w-0">
                                            <p className="font-bold text-gray-800 text-sm">{order?.deliveryAddress?.fullName || '—'}</p>
                                            <p className="font-mono text-xs text-indigo-600 mt-0.5 truncate">{txn.tid}</p>
                                        </div>
                                        <div className="flex-shrink-0 flex flex-col items-end gap-1">
                                            <span className="font-black text-green-700">₹{Number(txn.amount).toLocaleString('en-IN')}</span>
                                            <StatusBadge status={txn.status} />
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 mb-3">
                                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${txn.payType === 'phonepe' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                                            {txn.payType?.toUpperCase()}
                                        </span>
                                        <span className="text-xs text-gray-400">{formatDate(txn.createdAt)}</span>
                                        <button onClick={() => setExpandedRow(isOpen ? null : txn.tid)}
                                            className="ml-auto text-xs text-indigo-600 hover:underline">{isOpen ? 'Less ▲' : 'Details ▼'}</button>
                                    </div>
                                    {isOpen && order && (
                                        <div className="bg-gray-50 rounded-xl p-3 mb-3 text-xs text-gray-600 space-y-1">
                                            <p><span className="font-semibold">Order:</span> {order.orderNumber}</p>
                                            <p><span className="font-semibold">Address:</span> {order.deliveryAddress?.address}, {order.deliveryAddress?.city}</p>
                                            {order.products?.map((p, i) => <p key={i}>· {p.quantity}× {p.name} — ₹{p.dmartPrice}</p>)}
                                        </div>
                                    )}
                                    <div className="flex gap-2">
                                        {txn.status === 'pending' && (
                                            <>
                                                <button onClick={() => handleApprove(txn.tid)} disabled={!!aLoad}
                                                    className="flex-1 py-2 rounded-xl font-bold text-sm bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 shadow-md">
                                                    {aLoad === 'approve' ? '...' : '✅ Approve'}
                                                </button>
                                                <button onClick={() => handleReject(txn.tid)} disabled={!!aLoad}
                                                    className="flex-1 py-2 rounded-xl font-bold text-sm border-2 border-red-400 text-red-600 hover:bg-red-50 disabled:opacity-50">
                                                    {aLoad === 'reject' ? '...' : 'Reject'}
                                                </button>
                                            </>
                                        )}
                                        <button onClick={() => openDeleteModal(txn)} disabled={!!aLoad}
                                            className="p-2 rounded-xl font-bold text-sm border border-gray-200 text-gray-400 hover:text-red-500 hover:border-red-200 hover:bg-red-50 disabled:opacity-40 transition-all">
                                            🗑️
                                        </button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Pagination */}
            {pagination.totalPages > 1 && (
                <div className="flex items-center justify-between mt-4 flex-wrap gap-3">
                    <p className="text-sm text-gray-500">Page {pagination.currentPage} of {pagination.totalPages}</p>
                    <div className="flex gap-2">
                        <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}
                            className="px-3 py-2 text-sm font-semibold border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40">← Prev</button>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={!pagination.hasNextPage}
                            className="px-3 py-2 text-sm font-semibold border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40">Next →</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TransactionHistory;