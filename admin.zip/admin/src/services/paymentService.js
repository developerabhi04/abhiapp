import apiClient from './api';

class PaymentService {
    async getAllTransactions(params = {}) {
        try {
            const queryParams = new URLSearchParams(params).toString();
            const response = await apiClient.get(`/payment/transactions?${queryParams}`);
            return response.data;
        } catch (error) { throw error.response?.data || error; }
    }

    async approvePayment(tid) {
        try {
            const response = await apiClient.post('/payment/admin-approve', { tid });
            return response.data;
        } catch (error) { throw error.response?.data || error; }
    }

    async rejectPayment(tid) {
        try {
            const response = await apiClient.post('/payment/admin-reject', { tid });
            return response.data;
        } catch (error) { throw error.response?.data || error; }
    }

    async getTransactionStatus(tid) {
        try {
            const response = await apiClient.get(`/payment/status/${tid}`);
            return response.data;
        } catch (error) { throw error.response?.data || error; }
    }

    // ✅ NEW: Delete transaction by TID
    async deleteTransaction(tid) {
        try {
            const response = await apiClient.delete(`/payment/transaction/${tid}`);
            return response.data;
        } catch (error) { throw error.response?.data || error; }
    }

    // ✅ NEW: Create payment (called from Checkout.jsx)
    async createPayment(payload) {
        try {
            const response = await apiClient.post('/payment/create', payload);
            return response.data;
        } catch (error) { throw error.response?.data || error; }
    }
}

export default new PaymentService();