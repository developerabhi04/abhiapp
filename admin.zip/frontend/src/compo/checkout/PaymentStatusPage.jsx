import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useMetaPixel from '../../hooks/useMetaPixel';

const PaymentStatusPage = () => {
    const navigate = useNavigate();
    const { trackPurchase } = useMetaPixel();

    const orderId = localStorage.getItem('order_id');
    const amount = localStorage.getItem('payment_amount');
    const orderNumber = localStorage.getItem('order_number');

    useEffect(() => {
        if (!orderId) { navigate('/'); return; }

        // Fire pixel once for COD order placement
        try {
            const orderData = JSON.parse(localStorage.getItem('order_data') || '{}');
            trackPurchase({
                content_ids: orderData.productIds || [],
                value: parseFloat(amount) || 0,
                currency: 'INR',
                num_items: orderData.totalItems || 1,
            });
        } catch (e) {
            console.warn('Pixel error:', e);
        }
    }, []);

    const clearStorage = () => {
        ['order_id', 'payment_amount', 'order_data', 'order_number', 'payment_method'].forEach(k =>
            localStorage.removeItem(k)
        );
    };

    if (!orderId) return null;

    return (
        <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 flex items-center justify-center px-4 py-8">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md mx-auto overflow-hidden">

                {/* Yellow top banner */}
                <div className="bg-gradient-to-r from-yellow-400 to-orange-400 px-6 py-8 text-center">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white/40">
                        <svg className="w-10 h-10 sm:w-12 sm:h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <h1 className="text-2xl sm:text-3xl font-black text-white mb-1">Order Placed! 🎉</h1>
                    <p className="text-yellow-100 text-sm sm:text-base">
                        Your order is confirmed and pending delivery
                    </p>
                </div>

                <div className="px-5 sm:px-8 py-6">

                    {/* Order details */}
                    <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mb-6 space-y-3">
                        {orderNumber && (
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-500">Order No.</span>
                                <span className="font-bold text-gray-800 text-sm">#{orderNumber}</span>
                            </div>
                        )}
                        {amount && (
                            <div className="flex items-center justify-between border-t border-yellow-200 pt-3">
                                <span className="text-sm font-semibold text-gray-700">Order Amount</span>
                                <span className="text-xl font-black text-orange-600">
                                    ₹{parseFloat(amount).toLocaleString('en-IN')}
                                </span>
                            </div>
                        )}
                        <div className="flex items-center justify-between border-t border-yellow-200 pt-3">
                            <span className="text-sm text-gray-500">Payment</span>
                            <span className="text-sm font-bold text-green-700 bg-green-100 px-2 py-0.5 rounded-full">Cash on Delivery</span>
                        </div>
                    </div>

                    {/* Steps */}
                    <div className="space-y-2 mb-6">
                        {[
                            { icon: '✅', text: 'Order placed successfully' },
                            { icon: '📦', text: 'Our team is preparing your order' },
                            { icon: '💵', text: 'Pay cash when it arrives at your door' },
                            { icon: '🚚', text: 'You will be notified once dispatched' },
                        ].map((step, i) => (
                            <div key={i} className="flex items-center gap-3 text-sm text-gray-600">
                                <span className="text-lg">{step.icon}</span>
                                <span>{step.text}</span>
                            </div>
                        ))}
                    </div>

                    <button
                        onClick={() => { clearStorage(); navigate('/'); }}
                        className="w-full bg-orange-500 text-white py-4 rounded-2xl font-bold text-base sm:text-lg hover:bg-orange-600 active:scale-95 transition-all"
                    >
                        Continue Shopping 🛍️
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PaymentStatusPage;